import json
import requests
import boto3
import os

def lambda_handler(event, context):
   
    s3_bucket_name = "ifood-case-data-lake-vitor"
    s3_client = boto3.client('s3')

    # Defina os tipos de táxi e os meses
    taxi_types = ['yellow', 'green', 'fhv', 'fhvhv']
    months = ['01', '02', '03', '04', '05']
    year = '2023'
    base_url = "https://d37ci6vzurychx.cloudfront.net/trip-data/"

    timeout_seconds = 300

    for taxi_type in taxi_types:
        for month in months:
            #Usando o prefixo 'fhvhv' para o tipo de táxi de alto volume
            filename_prefix = 'fhvhv' if taxi_type == 'fhvhv' else taxi_type
            filename = f"{filename_prefix}_tripdata_{year}-{month}.parquet"
            url = f"{base_url}{filename}"
            
            try:
                print(f"Tentando baixar o arquivo: {filename}")
                
                with requests.get(url, stream=True, timeout=timeout_seconds) as response:
                    response.raise_for_status()
                    s3_client.upload_fileobj(
                        response.raw,
                        s3_bucket_name,
                        f"landing_zone/{filename}"
                    )
                
                print(f"Arquivo {filename} salvo no S3 .")
            except Exception as e:
                print(f"Erro ao processar o arquivo {filename}: {e}")
                
    return {
        'statusCode': 200,
        'body': json.dumps('Ingestão concluída (verifique os logs para erros)!')
    }